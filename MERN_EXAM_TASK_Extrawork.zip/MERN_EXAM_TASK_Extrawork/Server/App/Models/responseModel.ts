export interface responseModel{
    status?:number|null,
    message?:string|null,
    error?:string|null,
    data?:any|null

}
