import authrepositary from "./authrepositary/authrepositary"
import getSupplierrepositary from "./supplierrepositary/getSupplierrepositary"
import postInvoicerepositary from "./invoicerepositary/postInvoicerepositary"




export default{
    authrepositary,
    getSupplierrepositary,
    postInvoicerepositary

}