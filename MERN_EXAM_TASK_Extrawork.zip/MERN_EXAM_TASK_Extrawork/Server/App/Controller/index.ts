import authcontroller from "./auth/authcontroller"

export default{
    authcontroller

}