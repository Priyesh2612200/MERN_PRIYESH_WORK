import server from './Server'
const app = new server();
app.start();